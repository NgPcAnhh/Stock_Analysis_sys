--
-- PostgreSQL database dump
--

\restrict 3snmbl2zoKPJJnfKhtVHWNZsFbvQiD1PEg7yXhpja9z9mlSWOkzBrEZtB5NIG7e

-- Dumped from database version 16.12 (Debian 16.12-1.pgdg13+1)
-- Dumped by pg_dump version 16.12 (Debian 16.12-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: system; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA system;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: article_clicks; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.article_clicks (
    id bigint NOT NULL,
    article_id integer NOT NULL,
    session_id character varying(64) DEFAULT 'anonymous'::character varying NOT NULL,
    ip_address character varying(45),
    clicked_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: article_clicks_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.article_clicks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: article_clicks_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.article_clicks_id_seq OWNED BY system.article_clicks.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.password_reset_tokens (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    token character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.password_reset_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.password_reset_tokens_id_seq OWNED BY system.password_reset_tokens.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.refresh_tokens (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    token character varying(512) NOT NULL,
    device_info character varying(255),
    ip_address character varying(45),
    expires_at timestamp with time zone NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.refresh_tokens_id_seq OWNED BY system.refresh_tokens.id;


--
-- Name: roles; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.roles_id_seq OWNED BY system.roles.id;


--
-- Name: search_logs; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.search_logs (
    id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    session_id character varying(64) DEFAULT 'anonymous'::character varying NOT NULL,
    ip_address character varying(45),
    searched_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: search_logs_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.search_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: search_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.search_logs_id_seq OWNED BY system.search_logs.id;


--
-- Name: stock_clicks; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.stock_clicks (
    id bigint NOT NULL,
    ticker character varying(20) NOT NULL,
    session_id character varying(64) DEFAULT 'anonymous'::character varying NOT NULL,
    ip_address character varying(45),
    clicked_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_clicks_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.stock_clicks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_clicks_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.stock_clicks_id_seq OWNED BY system.stock_clicks.id;


--
-- Name: stock_search_logs; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.stock_search_logs (
    id bigint NOT NULL,
    keyword character varying(255) NOT NULL,
    session_id character varying(64) DEFAULT 'anonymous'::character varying NOT NULL,
    ip_address character varying(45),
    searched_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_search_logs_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.stock_search_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_search_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.stock_search_logs_id_seq OWNED BY system.stock_search_logs.id;


--
-- Name: users; Type: TABLE; Schema: system; Owner: -
--

CREATE TABLE system.users (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255),
    full_name character varying(255),
    avatar_url text,
    role_id integer DEFAULT 1 NOT NULL,
    auth_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    google_id character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: system; Owner: -
--

CREATE SEQUENCE system.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: system; Owner: -
--

ALTER SEQUENCE system.users_id_seq OWNED BY system.users.id;


--
-- Name: article_clicks id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.article_clicks ALTER COLUMN id SET DEFAULT nextval('system.article_clicks_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('system.password_reset_tokens_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('system.refresh_tokens_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.roles ALTER COLUMN id SET DEFAULT nextval('system.roles_id_seq'::regclass);


--
-- Name: search_logs id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.search_logs ALTER COLUMN id SET DEFAULT nextval('system.search_logs_id_seq'::regclass);


--
-- Name: stock_clicks id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.stock_clicks ALTER COLUMN id SET DEFAULT nextval('system.stock_clicks_id_seq'::regclass);


--
-- Name: stock_search_logs id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.stock_search_logs ALTER COLUMN id SET DEFAULT nextval('system.stock_search_logs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.users ALTER COLUMN id SET DEFAULT nextval('system.users_id_seq'::regclass);


--
-- Data for Name: article_clicks; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.article_clicks (id, article_id, session_id, ip_address, clicked_at) FROM stdin;
1	145	16800e2d-2aff-478a-97f7-c95fb6875877	127.0.0.1	2026-02-28 08:35:35.124588+00
2	145	16800e2d-2aff-478a-97f7-c95fb6875877	127.0.0.1	2026-02-28 08:35:47.267893+00
3	147	16800e2d-2aff-478a-97f7-c95fb6875877	127.0.0.1	2026-02-28 08:47:12.87179+00
4	107	16800e2d-2aff-478a-97f7-c95fb6875877	127.0.0.1	2026-03-01 02:12:50.534572+00
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.password_reset_tokens (id, user_id, token, expires_at, used, created_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.refresh_tokens (id, user_id, token, device_info, ip_address, expires_at, revoked, created_at) FROM stdin;
1	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzMyNDA3MDl9.sbgwMC05d4MgauI7qZDuV-2oUDpn1L6Q844g2J_1Kww	python-httpx/0.28.1	127.0.0.1	2026-03-11 14:51:49.793065+00	f	2026-03-04 07:51:49.795079+00
2	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzMyNDE2NTZ9.j6OG_rH8wZGGDFSO_ytsg-ogo-kPa-9kLwnXhMDwdhQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-11 15:07:36.435547+00	t	2026-03-04 08:07:36.440178+00
3	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzMyNDIwNTd9.1U2D0dCknO5ePB5Kevh092lSO8C7QD0TzvYvrKyFRvI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.109.5 Chrome/142.0.7444.265 Electron/39.3.0 Safari/537.36	127.0.0.1	2026-03-11 15:14:17.465718+00	t	2026-03-04 08:14:17.467227+00
4	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzMyNDIxMjl9.W_ViAl7I0XUVUEkWkdQNCFaqaq5F5SujySWlXWspNz0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.109.5 Chrome/142.0.7444.265 Electron/39.3.0 Safari/537.36	127.0.0.1	2026-03-11 15:15:29.569563+00	f	2026-03-04 08:15:29.570619+00
5	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzMyNDI2OTh9.NInpTpNdI1dqh7_U4w2tqE47O9qgeo4Ad2dxvesJqN0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-11 15:24:58.092235+00	t	2026-03-04 08:24:58.092235+00
6	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NTY1ODh9.0Hc5rtiTe8B9IvjEKZHn1SPyjbsGgGQRuWFXFeOot_s	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 02:49:48.85862+00	f	2026-03-06 19:49:48.894593+00
7	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NTgyOTB9.u8H-s65jiuykgFcKMOov4YZJGcnW7BCv8jpxXvMcSbU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 03:18:10.518659+00	t	2026-03-06 20:18:10.521447+00
8	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NTg5ODF9.KY2MxHRWzIobpKZ4zukZZPLJH72OTGBJ9Q_7rwKr69s	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 03:29:41.032943+00	f	2026-03-06 20:29:41.035654+00
9	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NjAwNzJ9.CIyk4FUJagexmZmirTu1U6sfarw4UU0jPfUzmQgRCLk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 03:47:52.912245+00	f	2026-03-06 20:47:52.927687+00
10	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NjIxMjF9._mXBA__89iaohEB0Jvgb1vqUndYpiyS9y09VAgVeVMk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 04:22:01.292059+00	f	2026-03-06 21:22:01.29988+00
11	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NjMwNDd9.gg_sw7p003cXXNhrJuPslvJDyGzyEsNP74vrcbRWAzs	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 04:37:27.196114+00	t	2026-03-06 21:37:27.202731+00
12	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NjM5NTl9.NIonJYqDeCit93r4RNboNpsWuaJqihqPnTxjACd04IA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 04:52:39.694171+00	t	2026-03-06 21:52:39.694699+00
13	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwidHlwZSI6InJlZnJlc2giLCJleHAiOjE3NzM0NjM5OTZ9.z2mEppb2wCr3te9fuhEmxizxSd7WnHLD_eTTYq3x34o	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0	127.0.0.1	2026-03-14 04:53:16.684924+00	t	2026-03-06 21:53:16.68646+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.roles (id, name, description, created_at) FROM stdin;
1	user	Người dùng thông thường	2026-03-04 14:44:51.795992+00
2	admin	Quản trị viên hệ thống	2026-03-04 14:44:51.795992+00
3	moderator	Kiểm duyệt nội dung	2026-03-04 14:44:51.795992+00
\.


--
-- Data for Name: search_logs; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.search_logs (id, keyword, session_id, ip_address, searched_at) FROM stdin;
1	ceo	16800e2d-2aff-478a-97f7-c95fb6875877	127.0.0.1	2026-02-28 08:36:05.347657+00
2	trump	16800e2d-2aff-478a-97f7-c95fb6875877	127.0.0.1	2026-02-28 08:54:12.617638+00
\.


--
-- Data for Name: stock_clicks; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.stock_clicks (id, ticker, session_id, ip_address, clicked_at) FROM stdin;
1	VCB	test123	127.0.0.1	2026-02-28 09:22:15.06205+00
2	BMC	s_1772271280615_bx47cm	127.0.0.1	2026-02-28 09:34:40.637772+00
3	VIC	s_1772376907986_4clqry	127.0.0.1	2026-03-01 14:55:08.009969+00
4	VIC	s_1772376907986_4clqry	127.0.0.1	2026-03-01 14:56:48.888548+00
5	VCB	s_1772376907986_4clqry	127.0.0.1	2026-03-01 14:57:00.027799+00
6	AAA	s_1772376907986_4clqry	127.0.0.1	2026-03-01 17:02:33.125527+00
7	VIC	s_1772418769479_871tho	127.0.0.1	2026-03-02 02:32:49.494335+00
8	VIC	s_1772418769479_871tho	127.0.0.1	2026-03-02 02:33:51.854926+00
9	VIC	s_1772418769479_871tho	127.0.0.1	2026-03-02 02:34:06.661129+00
10	VIC	s_1772418769479_871tho	127.0.0.1	2026-03-02 02:47:03.432242+00
11	VIC	s_1772418769479_871tho	127.0.0.1	2026-03-02 02:49:10.619216+00
12	VIC	s_1772459117200_ejmcn8	127.0.0.1	2026-03-02 13:45:17.230766+00
13	VIC	s_1772459117200_ejmcn8	127.0.0.1	2026-03-02 13:54:33.067318+00
14	VIC	s_1772459117200_ejmcn8	127.0.0.1	2026-03-02 14:02:34.620714+00
15	VIC	s_1772459117200_ejmcn8	127.0.0.1	2026-03-02 14:15:29.940335+00
16	VIC	s_1772466702292_iunbcr	127.0.0.1	2026-03-02 15:51:42.307885+00
17	VIC	s_1772500078071_444gf8	127.0.0.1	2026-03-03 01:07:58.100361+00
18	VIC	s_1772500078071_444gf8	127.0.0.1	2026-03-03 02:51:55.835916+00
19	VIC	s_1772500078071_444gf8	127.0.0.1	2026-03-03 06:53:13.230901+00
20	VIC	s_1772632873642_7j6k1s	127.0.0.1	2026-03-04 14:01:13.691395+00
21	VIC	s_1772632873642_7j6k1s	127.0.0.1	2026-03-04 14:01:42.245141+00
22	VIC	s_1772632873642_7j6k1s	127.0.0.1	2026-03-04 14:29:45.710724+00
23	VIC	s_1772632873642_7j6k1s	127.0.0.1	2026-03-04 14:54:29.106616+00
24	VIC	s_1772636415708_fffx8u	127.0.0.1	2026-03-04 15:00:15.836847+00
25	VIC	s_1772636415708_fffx8u	127.0.0.1	2026-03-04 15:25:06.162536+00
26	VIC	s_1772851805757_stixtf	127.0.0.1	2026-03-07 02:50:05.811983+00
27	VIC	s_1772851805757_stixtf	127.0.0.1	2026-03-07 04:24:11.982077+00
28	VIC	s_1772851805757_stixtf	127.0.0.1	2026-03-07 04:41:13.060367+00
29	VIC	s_1772851805757_stixtf	127.0.0.1	2026-03-07 04:45:31.054009+00
30	VIC	s_1772851805757_stixtf	127.0.0.1	2026-03-07 04:53:22.082419+00
31	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 11:34:41.947939+00
32	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 13:42:49.693288+00
33	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 13:54:25.487225+00
34	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 13:54:38.86091+00
35	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 13:58:08.019333+00
36	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:15:20.968489+00
37	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:22:08.485395+00
38	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:22:51.90577+00
39	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:26:50.474842+00
40	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:45:47.798634+00
41	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:48:29.961249+00
42	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:49:33.556626+00
43	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 14:56:01.296947+00
44	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 15:12:22.755689+00
45	VIC	s_1772969681932_xkfjin	127.0.0.1	2026-03-08 15:13:26.902783+00
\.


--
-- Data for Name: stock_search_logs; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.stock_search_logs (id, keyword, session_id, ip_address, searched_at) FROM stdin;
1	vcb	test123	127.0.0.1	2026-02-28 09:22:19.805448+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: system; Owner: -
--

COPY system.users (id, email, hashed_password, full_name, avatar_url, role_id, auth_provider, google_id, is_active, is_verified, last_login_at, created_at, updated_at) FROM stdin;
1	pcanh@admin.com	$2b$12$UAUg1IacHx2.8UAk4rdoJ.M/4ZDnxESwem6mbDQuq0DvheaOwgmLi	admin pcanh	\N	2	local	\N	t	t	2026-03-07 04:53:16.675538+00	2026-03-04 07:48:27.026696+00	2026-03-06 21:53:16.677766+00
\.


--
-- Name: article_clicks_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.article_clicks_id_seq', 4, true);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.password_reset_tokens_id_seq', 1, false);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.refresh_tokens_id_seq', 21, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.roles_id_seq', 3, true);


--
-- Name: search_logs_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.search_logs_id_seq', 2, true);


--
-- Name: stock_clicks_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.stock_clicks_id_seq', 45, true);


--
-- Name: stock_search_logs_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.stock_search_logs_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: system; Owner: -
--

SELECT pg_catalog.setval('system.users_id_seq', 1, true);


--
-- Name: article_clicks article_clicks_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.article_clicks
    ADD CONSTRAINT article_clicks_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_key; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_key UNIQUE (token);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: search_logs search_logs_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.search_logs
    ADD CONSTRAINT search_logs_pkey PRIMARY KEY (id);


--
-- Name: stock_clicks stock_clicks_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.stock_clicks
    ADD CONSTRAINT stock_clicks_pkey PRIMARY KEY (id);


--
-- Name: stock_search_logs stock_search_logs_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.stock_search_logs
    ADD CONSTRAINT stock_search_logs_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_google_id_key; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.users
    ADD CONSTRAINT users_google_id_key UNIQUE (google_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_article_clicks_article; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_article_clicks_article ON system.article_clicks USING btree (article_id);


--
-- Name: idx_article_clicks_article_session; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_article_clicks_article_session ON system.article_clicks USING btree (article_id, session_id);


--
-- Name: idx_article_clicks_time; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_article_clicks_time ON system.article_clicks USING btree (clicked_at DESC);


--
-- Name: idx_pwd_reset_token; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_pwd_reset_token ON system.password_reset_tokens USING btree (token);


--
-- Name: idx_pwd_reset_user; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_pwd_reset_user ON system.password_reset_tokens USING btree (user_id);


--
-- Name: idx_refresh_tokens_expires; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_refresh_tokens_expires ON system.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_token; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_refresh_tokens_token ON system.refresh_tokens USING btree (token);


--
-- Name: idx_refresh_tokens_user; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_refresh_tokens_user ON system.refresh_tokens USING btree (user_id);


--
-- Name: idx_search_logs_keyword; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_search_logs_keyword ON system.search_logs USING btree (keyword);


--
-- Name: idx_search_logs_keyword_time; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_search_logs_keyword_time ON system.search_logs USING btree (keyword, searched_at DESC);


--
-- Name: idx_search_logs_time; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_search_logs_time ON system.search_logs USING btree (searched_at DESC);


--
-- Name: idx_stock_clicks_ticker; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_stock_clicks_ticker ON system.stock_clicks USING btree (ticker);


--
-- Name: idx_stock_clicks_ticker_session; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_stock_clicks_ticker_session ON system.stock_clicks USING btree (ticker, session_id);


--
-- Name: idx_stock_clicks_time; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_stock_clicks_time ON system.stock_clicks USING btree (clicked_at DESC);


--
-- Name: idx_stock_search_logs_keyword; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_stock_search_logs_keyword ON system.stock_search_logs USING btree (keyword);


--
-- Name: idx_stock_search_logs_keyword_time; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_stock_search_logs_keyword_time ON system.stock_search_logs USING btree (keyword, searched_at DESC);


--
-- Name: idx_stock_search_logs_time; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_stock_search_logs_time ON system.stock_search_logs USING btree (searched_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_users_email ON system.users USING btree (email);


--
-- Name: idx_users_google_id; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_users_google_id ON system.users USING btree (google_id) WHERE (google_id IS NOT NULL);


--
-- Name: idx_users_role; Type: INDEX; Schema: system; Owner: -
--

CREATE INDEX idx_users_role ON system.users USING btree (role_id);


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES system.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES system.users(id) ON DELETE CASCADE;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: system; Owner: -
--

ALTER TABLE ONLY system.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES system.roles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 3snmbl2zoKPJJnfKhtVHWNZsFbvQiD1PEg7yXhpja9z9mlSWOkzBrEZtB5NIG7e

